package com.topazmobile

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.widget.*
import com.topazmobile.engine.VideoEnhancer
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private var input: Uri? = null
    private lateinit var enhance: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var comparisonCard: LinearLayout
    private lateinit var comparisonView: ComparisonView
    private val pick = 10

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        val select = findViewById<Button>(R.id.selectButton)
        enhance = findViewById(R.id.enhanceButton)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.statusText)
        comparisonCard = findViewById(R.id.comparisonCard)
        comparisonView = findViewById(R.id.comparisonView)
        val spinner = findViewById<Spinner>(R.id.qualitySpinner)
        val seek = findViewById<SeekBar>(R.id.comparisonSeek)

        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf(
            "1080p • super-resolução",
            "1440p • super-resolução",
            "4K • super-resolução"
        ))
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { comparisonView.setPosition(p / 100f) }
            override fun onStartTrackingTouch(s: SeekBar?) = Unit
            override fun onStopTrackingTouch(s: SeekBar?) = Unit
        })
        select.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "video/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, pick)
        }
        enhance.setOnClickListener {
            val u = input ?: return@setOnClickListener
            enhance.isEnabled = false
            comparisonCard.visibility = android.view.View.GONE
            progress.progress = 0
            status.text = "Preparando IA..."
            VideoEnhancer(this, u, spinner.selectedItemPosition, object : VideoEnhancer.Listener {
                override fun progress(p: Int, msg: String) = runOnUiThread { progress.progress = p; status.text = msg }
                override fun done(uri: Uri) {
                    runOnUiThread {
                        enhance.isEnabled = true
                        status.text = "Concluído • salvo na galeria"
                        Toast.makeText(this@MainActivity, "Vídeo salvo em Movies/TopazMobile", Toast.LENGTH_LONG).show()
                    }
                    loadComparison(u, uri)
                }
                override fun error(t: Throwable) = runOnUiThread {
                    enhance.isEnabled = true
                    status.text = "Falha: ${t.message ?: "erro desconhecido"}"
                    Toast.makeText(this@MainActivity, "Falha no processamento", Toast.LENGTH_LONG).show()
                }
            }).execute()
        }
    }

    private fun loadComparison(beforeUri: Uri, afterUri: Uri) {
        Executors.newSingleThreadExecutor().execute {
            try {
                val before = frame(beforeUri)
                val after = frame(afterUri)
                runOnUiThread {
                    comparisonView.setImages(before, after)
                    comparisonCard.visibility = android.view.View.VISIBLE
                }
            } catch (_: Throwable) { }
        }
    }

    private fun frame(uri: Uri): Bitmap {
        val r = MediaMetadataRetriever()
        r.setDataSource(this, uri)
        val b = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST)
            ?: throw IllegalStateException("Não foi possível gerar a prévia")
        r.release()
        return b
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == pick && res == Activity.RESULT_OK) {
            input = data?.data
            data?.data?.let { uri -> try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) {} }
            findViewById<TextView>(R.id.fileText).text = input?.toString() ?: "Nenhum vídeo selecionado"
            enhance.isEnabled = input != null
        }
    }
}
