package com.topazmobile.engine

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.media.*
import android.net.Uri
import android.provider.MediaStore
import java.nio.ByteBuffer
import java.util.concurrent.Executors

class VideoEnhancer(private val ctx: Context, private val input: Uri, private val mode: Int, private val listener: Listener) {
    interface Listener {
        fun progress(p: Int, msg: String)
        fun done(uri: Uri)
        fun error(t: Throwable)
    }

    fun execute() = Executors.newSingleThreadExecutor().execute {
        try { run() } catch (t: Throwable) { listener.error(t) }
    }

    private fun run() {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(ctx, input)
        val ex = MediaExtractor()
        ctx.contentResolver.openFileDescriptor(input, "r")!!.use { ex.setDataSource(it.fileDescriptor) }
        var vi = -1
        var ai = -1
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("video/")) vi = i
            if (mime.startsWith("audio/")) ai = i
        }
        if (vi < 0) throw IllegalStateException("Vídeo não encontrado")

        val vf = ex.getTrackFormat(vi)
        val ow = vf.getInteger(MediaFormat.KEY_WIDTH)
        val oh = vf.getInteger(MediaFormat.KEY_HEIGHT)
        val fps = if (vf.containsKey(MediaFormat.KEY_FRAME_RATE)) vf.getInteger(MediaFormat.KEY_FRAME_RATE) else 30
        val duration = if (vf.containsKey(MediaFormat.KEY_DURATION)) vf.getLong(MediaFormat.KEY_DURATION) else 0L
        if (duration <= 0) throw IllegalStateException("Não foi possível ler a duração do vídeo")

        // Target long-side: 1080p=1920, 1440p=2560, 4K=3840. Keep aspect ratio.
        val targetLong = when (mode) { 0 -> 1920; 1 -> 2560; else -> 3840 }
        val sourceLong = maxOf(ow, oh)
        val aiLong = sourceLong * 4L
        val finalLong = minOf(targetLong.toLong(), aiLong).toInt()
        val scale = finalLong.toDouble() / sourceLong.toDouble()
        val outW = (ow * scale).toInt().coerceAtLeast(2).let { if (it % 2 == 0) it else it - 1 }
        val outH = (oh * scale).toInt().coerceAtLeast(2).let { if (it % 2 == 0) it else it - 1 }

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "Topaz_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/TopazMobile")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val outUri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Não foi possível criar o arquivo de saída")
        val pfd = ctx.contentResolver.openFileDescriptor(outUri, "rw")
            ?: throw IllegalStateException("Não foi possível abrir o arquivo de saída")

        val mux = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val enc = MediaCodec.createEncoderByType("video/avc")
        val fmt = MediaFormat.createVideoFormat("video/avc", outW, outH).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, (outW * outH * fps * 0.075).toInt().coerceAtLeast(6_000_000))
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()

        var videoTrack = -1
        var audioTrack = -1
        var started = false
        val info = MediaCodec.BufferInfo()

        fun drain(end: Boolean = false) {
            while (true) {
                val id = enc.dequeueOutputBuffer(info, 10_000)
                if (id == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!end) break
                } else if (id == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    videoTrack = mux.addTrack(enc.outputFormat)
                    if (ai >= 0) audioTrack = mux.addTrack(ex.getTrackFormat(ai))
                    mux.start()
                    started = true
                } else if (id >= 0) {
                    val b = enc.getOutputBuffer(id) ?: continue
                    if (info.size > 0 && started) {
                        b.position(info.offset)
                        b.limit(info.offset + info.size)
                        mux.writeSampleData(videoTrack, b, info)
                    }
                    enc.releaseOutputBuffer(id, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                }
            }
        }

        val model = RealEsrgan(ctx)
        val frameStep = 1_000_000L / fps
        var t = 0L
        var frameNo = 0
        while (t < duration) {
            val bmp = retriever.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST) ?: break
            val ai = model.upscaleTo(bmp, outW, outH)
            val base = Bitmap.createScaledBitmap(bmp, outW, outH, true)
            val finalBmp = blendConservatively(base, ai, 0.82f)
            val canvas = surface.lockCanvas(null)
            canvas.drawColor(android.graphics.Color.BLACK)
            canvas.drawBitmap(finalBmp, null, Rect(0, 0, outW, outH), null)
            surface.unlockCanvasAndPost(canvas)
            bmp.recycle(); ai.recycle(); base.recycle(); finalBmp.recycle()
            drain()
            frameNo++
            t += frameStep
            listener.progress(((t * 100) / duration).toInt().coerceIn(0, 98), "IA • frame $frameNo • ${t / 1_000_000}s / ${duration / 1_000_000}s")
        }

        enc.signalEndOfInputStream()
        drain(true)

        if (started && ai >= 0) {
            val ae = MediaExtractor()
            ctx.contentResolver.openFileDescriptor(input, "r")!!.use { ae.setDataSource(it.fileDescriptor) }
            ae.selectTrack(ai)
            val buffer = ByteBuffer.allocate(1024 * 1024)
            while (true) {
                buffer.clear()
                val size = ae.readSampleData(buffer, 0)
                if (size < 0) break
                val bi = MediaCodec.BufferInfo().apply {
                    offset = 0; this.size = size; presentationTimeUs = ae.sampleTime; flags = ae.sampleFlags
                }
                mux.writeSampleData(audioTrack, buffer, bi)
                ae.advance()
            }
            ae.release()
        }

        if (started) mux.stop()
        mux.release(); enc.stop(); enc.release(); surface.release(); model.close(); retriever.release(); ex.release(); pfd.close()

        values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
        ctx.contentResolver.update(outUri, values, null, null)
        listener.progress(100, "Concluído • vídeo salvo na galeria")
        listener.done(outUri)
    }

    private fun blendConservatively(base: Bitmap, ai: Bitmap, aiWeight: Float): Bitmap {
        val w = ai.width; val h = ai.height
        val a = IntArray(w * h); val b = IntArray(w * h)
        base.getPixels(a, 0, w, 0, 0, w, h); ai.getPixels(b, 0, w, 0, 0, w, h)
        val out = IntArray(a.size)
        val bw = aiWeight.coerceIn(0f, 1f); val ow = 1f - bw
        for (i in out.indices) {
            val ap = a[i]; val bp = b[i]
            val r = (((ap shr 16) and 255) * ow + ((bp shr 16) and 255) * bw).toInt().coerceIn(0, 255)
            val g = (((ap shr 8) and 255) * ow + ((bp shr 8) and 255) * bw).toInt().coerceIn(0, 255)
            val bl = ((ap and 255) * ow + (bp and 255) * bw).toInt().coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }
}
