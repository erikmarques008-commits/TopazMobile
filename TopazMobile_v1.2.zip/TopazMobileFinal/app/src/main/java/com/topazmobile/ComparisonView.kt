package com.topazmobile

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

class ComparisonView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private var before: Bitmap? = null
    private var after: Bitmap? = null
    private var position = 0.5f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 3f }

    fun setImages(beforeBitmap: Bitmap?, afterBitmap: Bitmap?) {
        before?.recycle(); after?.recycle()
        before = beforeBitmap; after = afterBitmap
        invalidate()
    }

    fun setPosition(value: Float) { position = value.coerceIn(0f, 1f); invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = before ?: return
        val a = after ?: return
        canvas.drawColor(Color.rgb(12, 9, 18))
        val dst = fitRect(b, width, height)
        canvas.drawBitmap(b, null, dst, paint)
        val save = canvas.save()
        val split = dst.left + dst.width() * position
        canvas.clipRect(split, dst.top, dst.right, dst.bottom)
        canvas.drawBitmap(a, null, dst, paint)
        canvas.restoreToCount(save)
        canvas.drawLine(split, dst.top, split, dst.bottom, linePaint)
        paint.textSize = 12f
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.color = Color.WHITE
        canvas.drawText("ANTES", dst.left + 14f, dst.top + 22f, paint)
        canvas.drawText("DEPOIS", dst.right - 58f, dst.top + 22f, paint)
    }

    private fun fitRect(bitmap: Bitmap, vw: Int, vh: Int): RectF {
        val scale = min(vw.toFloat() / bitmap.width, vh.toFloat() / bitmap.height)
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        return RectF((vw - w) / 2f, (vh - h) / 2f, (vw + w) / 2f, (vh + h) / 2f)
    }
}
