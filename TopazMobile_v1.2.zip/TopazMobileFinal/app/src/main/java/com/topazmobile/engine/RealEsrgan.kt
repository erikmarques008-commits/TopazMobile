package com.topazmobile.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer
import java.util.zip.ZipInputStream
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession

/** Real-ESRGAN x4plus runner. Uses 128x128 tiles to bound RAM on phones. */
class RealEsrgan(private val ctx: Context) : AutoCloseable {
    companion object {
        private const val MODEL_NAME = "realesrgan-x4plus.onnx"
        private const val MIN_MODEL_BYTES = 60_000_000L
        // Qualcomm AI Hub public asset; avoids the Hugging Face DNS dependency.
        private const val MODEL_ZIP_URL =
            "https://qaihub-public-assets.s3.us-west-2.amazonaws.com/qai-hub-models/models/real_esrgan_x4plus/releases/v0.47.0/real_esrgan_x4plus-onnx-float.zip"
    }

    private val env = OrtEnvironment.getEnvironment()
    private val session: OrtSession

    init {
        val file = File(ctx.filesDir, MODEL_NAME)
        if (!file.exists() || file.length() < MIN_MODEL_BYTES) downloadModel(file)
        session = env.createSession(file.absolutePath, OrtSession.SessionOptions())
    }

    private fun downloadModel(file: File) {
        file.parentFile?.mkdirs()
        val zip = File(file.parent, "$MODEL_NAME.zip.part")
        if (zip.exists()) zip.delete()
        val connection = (URL(MODEL_ZIP_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 180_000
            instanceFollowRedirects = true
            requestMethod = "GET"
            connect()
        }
        try {
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("Não foi possível baixar a IA: HTTP ${connection.responseCode}")
            }
            connection.inputStream.use { input ->
                zip.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
            }
            if (zip.length() < 20_000_000L) throw IllegalStateException("Download da IA incompleto.")
            extractOnnx(zip, file)
            zip.delete()
            if (!file.exists() || file.length() < MIN_MODEL_BYTES) {
                throw IllegalStateException("O modelo de IA foi extraído incompleto.")
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun extractOnnx(zip: File, target: File) {
        ZipInputStream(FileInputStream(zip).buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.lowercase().endsWith(".onnx")) {
                    target.outputStream().use { out -> zis.copyTo(out, 1024 * 1024) }
                    return
                }
                entry = zis.nextEntry
            }
        }
        throw IllegalStateException("O pacote da IA não contém um modelo ONNX.")
    }

    fun upscale(src: Bitmap): Bitmap {
        val tile = 128
        val output = Bitmap.createBitmap(src.width * 4, src.height * 4, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        var y = 0
        while (y < src.height) {
            var x = 0
            while (x < src.width) {
                val tw = minOf(tile, src.width - x)
                val th = minOf(tile, src.height - y)
                val patch = Bitmap.createBitmap(tile, tile, Bitmap.Config.ARGB_8888)
                val pc = Canvas(patch)
                pc.drawColor(Color.BLACK)
                pc.drawBitmap(src, android.graphics.Rect(x, y, x + tw, y + th), android.graphics.Rect(0, 0, tw, th), null)
                if (tw < tile) pc.drawBitmap(patch, android.graphics.Rect(tw - 1, 0, tw, tile), android.graphics.Rect(tw, 0, tile, tile), null)
                if (th < tile) pc.drawBitmap(patch, android.graphics.Rect(0, th - 1, tile, th), android.graphics.Rect(0, th, tile, tile), null)

                val enhanced = upscaleTile(patch)
                canvas.drawBitmap(enhanced,
                    android.graphics.Rect(0, 0, tw * 4, th * 4),
                    android.graphics.Rect(x * 4, y * 4, (x + tw) * 4, (y + th) * 4), null)
                enhanced.recycle()
                patch.recycle()
                x += tw
            }
            y += tile
        }
        return output
    }

    fun upscaleTo(src: Bitmap, targetW: Int, targetH: Int): Bitmap {
        val tile = 128
        val output = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        var y = 0
        while (y < src.height) {
            var x = 0
            while (x < src.width) {
                val tw = minOf(tile, src.width - x)
                val th = minOf(tile, src.height - y)
                val patch = Bitmap.createBitmap(tile, tile, Bitmap.Config.ARGB_8888)
                val pc = Canvas(patch)
                pc.drawColor(Color.BLACK)
                pc.drawBitmap(src, android.graphics.Rect(x, y, x + tw, y + th), android.graphics.Rect(0, 0, tw, th), null)
                if (tw < tile) pc.drawBitmap(patch, android.graphics.Rect(tw - 1, 0, tw, tile), android.graphics.Rect(tw, 0, tile, tile), null)
                if (th < tile) pc.drawBitmap(patch, android.graphics.Rect(0, th - 1, tile, th), android.graphics.Rect(0, th, tile, tile), null)
                val enhanced = upscaleTile(patch)
                val left = (x.toDouble() / src.width * targetW).toInt()
                val top = (y.toDouble() / src.height * targetH).toInt()
                val right = ((x + tw).toDouble() / src.width * targetW).toInt().coerceAtLeast(left + 1)
                val bottom = ((y + th).toDouble() / src.height * targetH).toInt().coerceAtLeast(top + 1)
                canvas.drawBitmap(enhanced, null, android.graphics.Rect(left, top, right, bottom), null)
                enhanced.recycle(); patch.recycle()
                x += tw
            }
            y += tile
        }
        return output
    }

    private fun upscaleTile(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val pixelCount = w * h
        val values = FloatArray(pixelCount * 3)
        val pixels = IntArray(pixelCount)
        src.getPixels(pixels, 0, w, 0, 0, w, h)
        var i = 0
        for (p in pixels) values[i++] = ((p ushr 16) and 255) / 255f
        for (p in pixels) values[i++] = ((p ushr 8) and 255) / 255f
        for (p in pixels) values[i++] = (p and 255) / 255f

        val inputName = session.inputNames.first()
        val input = OnnxTensor.createTensor(env, FloatBuffer.wrap(values), longArrayOf(1, 3, h.toLong(), w.toLong()))
        val result = session.run(mapOf(inputName to input))
        try {
            val outputTensor = result[session.outputNames.first()] as OnnxTensor
            val shape = outputTensor.info.shape
            require(shape.size == 4 && shape[0] == 1L && shape[1] >= 3L) { "Formato de saída da IA não suportado." }
            val oh = shape[2].toInt()
            val ow = shape[3].toInt()
            val buffer = outputTensor.floatBuffer
            val out = IntArray(ow * oh)
            val plane = oh * ow
            for (yy in 0 until oh) {
                for (xx in 0 until ow) {
                    val idx = yy * ow + xx
                    fun convert(offset: Int): Int {
                        var v = buffer.get(offset + idx)
                        if (v < 0f) v = (v + 1f) * 0.5f
                        if (v <= 1.5f) v *= 255f
                        return v.coerceIn(0f, 255f).toInt()
                    }
                    out[idx] = (0xFF shl 24) or (convert(0) shl 16) or (convert(plane) shl 8) or convert(plane * 2)
                }
            }
            return Bitmap.createBitmap(out, ow, oh, Bitmap.Config.ARGB_8888)
        } finally {
            result.close()
            input.close()
        }
    }

    override fun close() { session.close() }
}
