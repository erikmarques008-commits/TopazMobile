package com.topazmobile.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession

/** Real-ESRGAN x4plus runner. The 128x128 model is tiled to keep RAM use bounded. */
class RealEsrgan(private val ctx: Context) : AutoCloseable {
    companion object {
        private const val MODEL_NAME = "realesrgan-x4plus.onnx"
        private const val MIN_MODEL_BYTES = 60_000_000L
        private const val MODEL_URL = "https://huggingface.co/qualcomm/Real-ESRGAN-x4plus/resolve/295b21e3e9a293025c8c0c9086e1aa800af310e4/Real-ESRGAN-x4plus.onnx?download=true"
    }

    private val env = OrtEnvironment.getEnvironment()
    private val session: OrtSession

    init {
        val file = File(ctx.filesDir, MODEL_NAME)
        if (!file.exists() || file.length() < MIN_MODEL_BYTES) downloadModel(file)
        session = env.createSession(file.absolutePath, OrtSession.SessionOptions())
    }

    private fun downloadModel(file: File) {
        file.parentFile?.mkdirs()
        val tmp = File(file.parent, "$MODEL_NAME.part")
        if (tmp.exists()) tmp.delete()
        val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 120_000
            instanceFollowRedirects = true
            requestMethod = "GET"
            connect()
        }
        try {
            if (connection.responseCode !in 200..399) {
                throw IllegalStateException("Falha ao baixar o modelo: HTTP ${connection.responseCode}")
            }
            connection.inputStream.use { input ->
                tmp.outputStream().use { output ->
                    input.copyTo(output, 1024 * 1024)
                }
            }
            if (tmp.length() < MIN_MODEL_BYTES) {
                throw IllegalStateException("O arquivo do modelo foi baixado incompleto.")
            }
            if (!tmp.renameTo(file)) {
                tmp.copyTo(file, overwrite = true)
                tmp.delete()
            }
        } finally {
            connection.disconnect()
        }
    }

    fun upscale(src: Bitmap): Bitmap {
        val tile = 128
        val output = Bitmap.createBitmap(src.width * 4, src.height * 4, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        var y = 0
        while (y < src.height) {
            var x = 0
            while (x < src.width) {
                val tw = minOf(tile, src.width - x)
                val th = minOf(tile, src.height - y)
                val patch = Bitmap.createBitmap(tile, tile, Bitmap.Config.ARGB_8888)
                val pc = Canvas(patch)
                pc.drawColor(Color.BLACK)
                pc.drawBitmap(src, android.graphics.Rect(x, y, x + tw, y + th), android.graphics.Rect(0, 0, tw, th), null)

                // Replicate the last valid row/column instead of leaving black padding.
                if (tw < tile) pc.drawBitmap(patch, android.graphics.Rect(tw - 1, 0, tw, tile), android.graphics.Rect(tw, 0, tile, tile), null)
                if (th < tile) pc.drawBitmap(patch, android.graphics.Rect(0, th - 1, tile, th), android.graphics.Rect(0, th, tile, tile), null)

                val enhanced = upscaleTile(patch)
                canvas.drawBitmap(
                    enhanced,
                    android.graphics.Rect(0, 0, tw * 4, th * 4),
                    android.graphics.Rect(x * 4, y * 4, (x + tw) * 4, (y + th) * 4),
                    null
                )
                enhanced.recycle()
                patch.recycle()
                x += tw
            }
            y += tile
        }
        return output
    }

    private fun upscaleTile(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val pixelCount = w * h
        val values = FloatArray(pixelCount * 3)
        val pixels = IntArray(pixelCount)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        var i = 0
        for (p in pixels) values[i++] = ((p ushr 16) and 255) / 255f
        for (p in pixels) values[i++] = ((p ushr 8) and 255) / 255f
        for (p in pixels) values[i++] = (p and 255) / 255f

        val inputName = session.inputNames.first()
        val input = OnnxTensor.createTensor(env, FloatBuffer.wrap(values), longArrayOf(1, 3, h.toLong(), w.toLong()))
        val result = session.run(mapOf(inputName to input))
        try {
            val outputTensor = result[session.outputNames.first()] as OnnxTensor
            val shape = outputTensor.info.shape
            require(shape.size == 4 && shape[0] == 1L && shape[1] >= 3L) {
                "Formato de saída do modelo não suportado: ${shape.contentToString()}"
            }
            val oh = shape[2].toInt()
            val ow = shape[3].toInt()
            val buffer = outputTensor.floatBuffer
            val out = IntArray(ow * oh)
            val plane = oh * ow
            val rBase = 0
            val gBase = plane
            val bBase = plane * 2
            for (y in 0 until oh) {
                for (x in 0 until ow) {
                    val idx = y * ow + x
                    fun convert(offset: Int): Int {
                        var v = buffer.get(offset + idx)
                        if (v < 0f) v = (v + 1f) * 0.5f
                        if (v <= 1.5f) v *= 255f
                        return v.coerceIn(0f, 255f).toInt()
                    }
                    out[idx] = (0xFF shl 24) or (convert(rBase) shl 16) or (convert(gBase) shl 8) or convert(bBase)
                }
            }
            return Bitmap.createBitmap(out, ow, oh, Bitmap.Config.ARGB_8888)
        } finally {
            result.close()
            input.close()
        }
    }

    override fun close() {
        session.close()
    }
}
